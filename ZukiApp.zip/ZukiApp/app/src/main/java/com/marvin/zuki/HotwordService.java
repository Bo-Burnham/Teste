package com.marvin.zuki;

import android.app.*;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.*;
import android.speech.*;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import android.os.Build;
import java.util.ArrayList;

public class HotwordService extends Service {

    public static final String ACTION_HOTWORD    = "com.marvin.zuki.HOTWORD_DETECTED";
    public static final String ACTION_TRANSCRIPT = "com.marvin.zuki.TRANSCRIPT";
    public static final String ACTION_PAUSE      = "com.marvin.zuki.HOTWORD_PAUSE";
    public static final String ACTION_RESUME     = "com.marvin.zuki.HOTWORD_RESUME";
    public static final String EXTRA_TEXT        = "text";

    private static final String CHANNEL_ID  = "zuki_hotword";
    private static final int    NOTIF_ID    = 2001;
    private static final String[] HOTWORDS = {
        "hey zuki", "hi zuki", "okay zuki", "ok zuki", "zuki"
    };

    private SpeechRecognizer recognizer;
    private boolean          running = false;
    private boolean          paused  = false;

    private final BroadcastReceiver controlReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (ACTION_PAUSE.equals(intent.getAction())) {
                paused = true;
                if (recognizer != null) {
                    recognizer.stopListening();
                    recognizer.destroy();
                    recognizer = null;
                }
            } else if (ACTION_RESUME.equals(intent.getAction())) {
                paused = false;
                _startListening();
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        _createChannel();
        startForeground(NOTIF_ID, _buildNotification());
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_PAUSE);
        filter.addAction(ACTION_RESUME);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(controlReceiver, filter, RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(controlReceiver, filter);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        running = true;
        _startListening();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        unregisterReceiver(controlReceiver);
        if (recognizer != null) {
            recognizer.stopListening();
            recognizer.destroy();
            recognizer = null;
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ── Speech ────────────────────────────────────────────────────────────────

    private void _startListening() {
        if (!running || paused) return;

        if (recognizer != null) {
            recognizer.destroy();
        }

        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String text = matches.get(0).toLowerCase();
                    String matched = null;
                    for (String hw : HOTWORDS) {
                        if (text.contains(hw)) { matched = hw; break; }
                    }
                    if (matched != null) {
                        // Broadcast hotword to MainActivity
                        Intent i = new Intent(ACTION_HOTWORD);
                        i.setPackage(getPackageName());
                        String remainder = text.replace(matched, "").trim();
                        if (!remainder.isEmpty()) {
                            i.putExtra(EXTRA_TEXT, remainder);
                        }
                        sendBroadcast(i);
                    }
                }
                // Restart to keep listening
                new Handler(Looper.getMainLooper()).postDelayed(
                        HotwordService.this::_startListening, 300);
            }

            @Override
            public void onError(int error) {
                // Restart on error after brief delay
                new Handler(Looper.getMainLooper()).postDelayed(
                        HotwordService.this::_startListening, 500);
            }

            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L);
        recognizer.startListening(intent);
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private void _createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, getString(R.string.notif_channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification _buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Zuki")
                .setContentText(getString(R.string.notif_text))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
                .build();
    }
}
