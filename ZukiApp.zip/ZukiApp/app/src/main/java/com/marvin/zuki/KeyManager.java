package com.marvin.zuki;

import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.util.*;

/**
 * Manages API keys stored in private app storage.
 * Keys are NEVER hardcoded — stored in keys.json in internal storage only.
 * Only this app can read that file. Not included in APK or backups.
 */
public class KeyManager {

    private static final String KEYS_FILE      = "keys.json";
    private static final String GROQ_KEY       = "groq";
    private static final String GEMINI_KEY     = "gemini";
    private static final String ELEVENLABS_KEY = "elevenlabs";
    private static final String ELEVENLABS_VOICE = "elevenlabs_voice_id";

    // Default keys — only used on first install to seed keys.json
    public static final String[] DEFAULT_GROQ_KEYS = {
        "REPLACE_WITH_YOUR_GROQ_KEY_1",
        "REPLACE_WITH_YOUR_GROQ_KEY_2",
        "REPLACE_WITH_YOUR_GROQ_KEY_3"
    };
    public static final String[] DEFAULT_GEMINI_KEYS = {
        "AIzaSyBGH3tb30SZUeY9YrVgmq0_5m_XACDzLXc",
        "AIzaSyCa5KUGxEVuZn-TEnNifVSiAIvUaneekfI",
        "AIzaSyBB4gZhviDA1coNow-emWuHA9YmJnTv3Fg",
        "AIzaSyC1N1x0ZZtYqn0DnpTH3Cu8IkKwcSnUZ0U",
        "AIzaSyBmQGVb_slp3JyGtzPvxT7EBBETK2HFrRg",
        "AIzaSyB2YpJe55VDzAvwMcRRuKV0hPioZBx_IoQ",
        "AIzaSyD52R8tIL4RtbsoLxTZb2sgxjhTWTSl3TA"
    };
    public static final String[] DEFAULT_ELEVENLABS_KEYS = {
        "09839f81dfefbc7d5e5095f40fcf16446782a5e91d74b391698c771d6f4b2ea4",
        "sk_efeddeb182c7bf44309988e6c61e4c6c45ace11ab6ffaaf4",
        "sk_0b932da73baa2858ec2c88cf8a8e290676512db0f7f7fcf7"
    };
    public static final String   DEFAULT_ELEVENLABS_VOICE = "0duPRxFCge5R3ZJInukg";

    private final Context ctx;
    private final Gson    gson = new Gson();

    // In-memory cache
    private Map<String, List<String>> keyStore = new HashMap<>();

    public KeyManager(Context ctx) {
        this.ctx = ctx;
        _load();
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public List<String> getGroqKeys()         { return _get(GROQ_KEY); }
    public List<String> getGeminiKeys()       { return _get(GEMINI_KEY); }
    public List<String> getElevenLabsKeys()   { return _get(ELEVENLABS_KEY); }

    public String getElevenLabsVoiceId() {
        List<String> v = _get(ELEVENLABS_VOICE);
        return v.isEmpty() ? "" : v.get(0);
    }

    public void setElevenLabsVoiceId(String voiceId) {
        List<String> v = new java.util.ArrayList<>();
        v.add(voiceId.trim());
        keyStore.put(ELEVENLABS_VOICE, v);
        _save();
    }

    public void addElevenLabsKey(String key) {
        List<String> keys = new java.util.ArrayList<>(_get(ELEVENLABS_KEY));
        if (!keys.contains(key.trim())) {
            keys.add(key.trim());
            keyStore.put(ELEVENLABS_KEY, keys);
            _save();
        }
    }

    public void removeElevenLabsKey(int index) {
        List<String> keys = new java.util.ArrayList<>(_get(ELEVENLABS_KEY));
        if (index >= 0 && index < keys.size()) {
            keys.remove(index);
            keyStore.put(ELEVENLABS_KEY, keys);
            _save();
        }
    }

    public boolean hasElevenLabsKeys() { return !_get(ELEVENLABS_KEY).isEmpty(); }

    public void setGroqKeys(List<String> keys) {
        keyStore.put(GROQ_KEY, keys);
        _save();
    }

    public void setGeminiKeys(List<String> keys) {
        keyStore.put(GEMINI_KEY, keys);
        _save();
    }

    public void addGroqKey(String key) {
        List<String> keys = new ArrayList<>(_get(GROQ_KEY));
        if (!keys.contains(key.trim())) {
            keys.add(key.trim());
            keyStore.put(GROQ_KEY, keys);
            _save();
        }
    }

    public void addGeminiKey(String key) {
        List<String> keys = new ArrayList<>(_get(GEMINI_KEY));
        if (!keys.contains(key.trim())) {
            keys.add(key.trim());
            keyStore.put(GEMINI_KEY, keys);
            _save();
        }
    }

    public void removeGroqKey(int index) {
        List<String> keys = new ArrayList<>(_get(GROQ_KEY));
        if (index >= 0 && index < keys.size()) {
            keys.remove(index);
            keyStore.put(GROQ_KEY, keys);
            _save();
        }
    }

    public void removeGeminiKey(int index) {
        List<String> keys = new ArrayList<>(_get(GEMINI_KEY));
        if (index >= 0 && index < keys.size()) {
            keys.remove(index);
            keyStore.put(GEMINI_KEY, keys);
            _save();
        }
    }

    public boolean hasGroqKeys()   { return !_get(GROQ_KEY).isEmpty(); }
    public boolean hasGeminiKeys() { return !_get(GEMINI_KEY).isEmpty(); }

    /** Seeds default keys on first install — call once from MainActivity */
    public void seedDefaultsIfEmpty(List<String> defaultGroq, List<String> defaultGemini) {
        // Merge — add any new default keys not already stored
        List<String> currentGroq = new ArrayList<>(_get(GROQ_KEY));
        for (String key : defaultGroq) {
            if (!currentGroq.contains(key)) currentGroq.add(key);
        }
        keyStore.put(GROQ_KEY, currentGroq);

        List<String> currentGemini = new ArrayList<>(_get(GEMINI_KEY));
        for (String key : defaultGemini) {
            if (!currentGemini.contains(key)) currentGemini.add(key);
        }
        keyStore.put(GEMINI_KEY, currentGemini);

        // Seed ElevenLabs keys
        List<String> currentEL = new ArrayList<>(_get(ELEVENLABS_KEY));
        for (String key : DEFAULT_ELEVENLABS_KEYS) {
            if (!currentEL.contains(key)) currentEL.add(key);
        }
        keyStore.put(ELEVENLABS_KEY, currentEL);

        // Set default voice ID if not set
        if (getElevenLabsVoiceId().isEmpty()) {
            setElevenLabsVoiceId(DEFAULT_ELEVENLABS_VOICE);
        }
        _save();
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private List<String> _get(String type) {
        List<String> keys = keyStore.get(type);
        return keys != null ? keys : new ArrayList<>();
    }

    private void _load() {
        try {
            File f = new File(ctx.getFilesDir(), KEYS_FILE);
            if (!f.exists()) return;
            BufferedReader reader = new BufferedReader(new FileReader(f));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            reader.close();
            Type type = new TypeToken<Map<String, List<String>>>(){}.getType();
            Map<String, List<String>> loaded = gson.fromJson(sb.toString(), type);
            if (loaded != null) {
                // Sanitize all keys — strip whitespace, newlines, invisible chars
                for (Map.Entry<String, List<String>> entry : loaded.entrySet()) {
                    List<String> cleaned = new java.util.ArrayList<>();
                    for (String key : entry.getValue()) {
                        String sanitized = key.replaceAll("[\\s\\r\\n\\t]", "").trim();
                        if (!sanitized.isEmpty()) cleaned.add(sanitized);
                    }
                    entry.setValue(cleaned);
                }
                keyStore = loaded;
            }
        } catch (Exception ignored) {}
    }

    private void _save() {
        try {
            File f = new File(ctx.getFilesDir(), KEYS_FILE);
            FileWriter writer = new FileWriter(f);
            writer.write(gson.toJson(keyStore));
            writer.close();
        } catch (Exception ignored) {}
    }
}
