package com.marvin.zuki;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class SettingsActivity extends AppCompatActivity {

    private KeyManager   keyManager;
    private LinearLayout llGroqKeys, llGeminiKeys, llElevenLabsKeys;
    private EditText     etNewGroqKey, etNewGeminiKey, etNewElevenLabsKey, etVoiceId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            keyManager = new KeyManager(this);
            setContentView(buildLayout());
        } catch (Exception e) {
            Toast.makeText(this, "Settings error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private View buildLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF000000);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 60, 32, 32);
        scroll.addView(root);

        // Title
        TextView title = new TextView(this);
        title.setText("⚙ Zuki Settings");
        title.setTextColor(0xFFA129D1);
        title.setTextSize(22);
        title.setPadding(0, 0, 0, 24);
        root.addView(title);

        // ── GROQ KEYS ──────────────────────────────────────────────────────
        addHeader(root, "🤖 Groq API Keys");
        addHint(root, "One key per Groq account. Each = separate rate limit.");
        llGroqKeys = new LinearLayout(this);
        llGroqKeys.setOrientation(LinearLayout.VERTICAL);
        root.addView(llGroqKeys);
        refreshKeys(llGroqKeys, "groq");
        etNewGroqKey = addKeyInput(root, "Paste new Groq key (gsk_...)");
        Button btnAddGroq = makeButton("+ Add Groq Key", 0xFF401060);
        btnAddGroq.setOnClickListener(v -> addKey(etNewGroqKey, "groq", "gsk_", llGroqKeys));
        root.addView(btnAddGroq);
        addDivider(root);

        // ── GEMINI KEYS ────────────────────────────────────────────────────
        addHeader(root, "👁️ Gemini API Keys");
        addHint(root, "For camera vision. Get free keys at aistudio.google.com");
        llGeminiKeys = new LinearLayout(this);
        llGeminiKeys.setOrientation(LinearLayout.VERTICAL);
        root.addView(llGeminiKeys);
        refreshKeys(llGeminiKeys, "gemini");
        etNewGeminiKey = addKeyInput(root, "Paste new Gemini key (AIza...)");
        Button btnAddGemini = makeButton("+ Add Gemini Key", 0xFF401060);
        btnAddGemini.setOnClickListener(v -> addKey(etNewGeminiKey, "gemini", "AIza", llGeminiKeys));
        root.addView(btnAddGemini);
        addDivider(root);

        // ── ELEVENLABS KEYS ────────────────────────────────────────────────
        addHeader(root, "🎙️ ElevenLabs API Keys");
        addHint(root, "For premium AI voice. Free at elevenlabs.io (10k chars/month each)");
        llElevenLabsKeys = new LinearLayout(this);
        llElevenLabsKeys.setOrientation(LinearLayout.VERTICAL);
        root.addView(llElevenLabsKeys);
        refreshKeys(llElevenLabsKeys, "elevenlabs");
        etNewElevenLabsKey = addKeyInput(root, "Paste new ElevenLabs key");
        Button btnAddEL = makeButton("+ Add ElevenLabs Key", 0xFF401060);
        btnAddEL.setOnClickListener(v -> addKey(etNewElevenLabsKey, "elevenlabs", "", llElevenLabsKeys));
        root.addView(btnAddEL);

        // Voice ID
        addHint(root, "Voice ID (from elevenlabs.io — leave as default for current voice)");
        etVoiceId = new EditText(this);
        String vid = keyManager.getElevenLabsVoiceId();
        etVoiceId.setText(vid.isEmpty() ? ElevenLabsClient.DEFAULT_VOICE_ID : vid);
        etVoiceId.setTextColor(0xFFEBDBFF);
        etVoiceId.setHintTextColor(0xFF8259A1);
        etVoiceId.setBackgroundColor(0xFF0F0520);
        etVoiceId.setPadding(20, 16, 20, 16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 4);
        etVoiceId.setLayoutParams(lp);
        root.addView(etVoiceId);
        Button btnSaveVoice = makeButton("💾 Save Voice ID", 0xFF401060);
        btnSaveVoice.setOnClickListener(v -> {
            String newVid = etVoiceId.getText().toString().trim();
            if (!newVid.isEmpty()) {
                keyManager.setElevenLabsVoiceId(newVid);
                hideKeyboard();
                Toast.makeText(this, "Voice ID saved!", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(btnSaveVoice);
        addDivider(root);

        // ── RESET ──────────────────────────────────────────────────────────
        Button btnReset = makeButton("🔄 Reset to Default Keys", 0xFF1a0a2e);
        btnReset.setOnClickListener(v -> {
            keyManager.setGroqKeys(Arrays.asList(KeyManager.DEFAULT_GROQ_KEYS));
            keyManager.setGeminiKeys(Arrays.asList(KeyManager.DEFAULT_GEMINI_KEYS));
            keyManager.seedDefaultsIfEmpty(
                Arrays.asList(KeyManager.DEFAULT_GROQ_KEYS),
                Arrays.asList(KeyManager.DEFAULT_GEMINI_KEYS));
            refreshKeys(llGroqKeys, "groq");
            refreshKeys(llGeminiKeys, "gemini");
            refreshKeys(llElevenLabsKeys, "elevenlabs");
            Toast.makeText(this, "Keys reset!", Toast.LENGTH_SHORT).show();
        });
        root.addView(btnReset);

        // ── DONE ───────────────────────────────────────────────────────────
        Button btnDone = makeButton("✓ Done", 0xFFA129D1);
        LinearLayout.LayoutParams doneLp = new LinearLayout.LayoutParams(-1, 120);
        doneLp.setMargins(0, 16, 0, 0);
        btnDone.setLayoutParams(doneLp);
        btnDone.setOnClickListener(v -> finish());
        root.addView(btnDone);

        return scroll;
    }

    // ── Key management ────────────────────────────────────────────────────────

    private void addKey(EditText input, String type, String prefix, LinearLayout list) {
        String key = input.getText().toString().trim();
        if (key.isEmpty()) { Toast.makeText(this, "Paste a key first", Toast.LENGTH_SHORT).show(); return; }
        if (!prefix.isEmpty() && !key.startsWith(prefix)) {
            Toast.makeText(this, "Invalid key format", Toast.LENGTH_SHORT).show(); return;
        }
        if ("groq".equals(type))         keyManager.addGroqKey(key);
        else if ("gemini".equals(type))  keyManager.addGeminiKey(key);
        else                             keyManager.addElevenLabsKey(key);
        input.setText("");
        hideKeyboard();
        refreshKeys(list, type);
        Toast.makeText(this, "Key added!", Toast.LENGTH_SHORT).show();
    }

    private void refreshKeys(LinearLayout container, String type) {
        container.removeAllViews();
        List<String> keys;
        if ("groq".equals(type))         keys = keyManager.getGroqKeys();
        else if ("gemini".equals(type))  keys = keyManager.getGeminiKeys();
        else                             keys = keyManager.getElevenLabsKeys();

        if (keys.isEmpty()) {
            addHint(container, "No keys added yet");
            return;
        }
        for (int i = 0; i < keys.size(); i++) {
            container.addView(keyRow(keys.get(i), i, type, container));
        }
    }

    private View keyRow(String key, int index, String type, LinearLayout container) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(0xFF111111);
        row.setPadding(20, 14, 20, 14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 4, 0, 4);
        row.setLayoutParams(lp);

        String masked = key.length() > 12
                ? key.substring(0, 8) + "••••" + key.substring(key.length() - 4)
                : "••••••••";
        TextView tv = new TextView(this);
        tv.setText("Key " + (index + 1) + ": " + masked);
        tv.setTextColor(0xFFEBDBFF);
        tv.setTextSize(13);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(tv);

        Button del = new Button(this);
        del.setText("✕");
        del.setTextColor(0xFFFFFFFF);
        del.setBackgroundColor(0xFF4F1E6D);
        del.setTextSize(12);
        del.setLayoutParams(new LinearLayout.LayoutParams(80, 70));
        del.setOnClickListener(v -> {
            if ("groq".equals(type))         keyManager.removeGroqKey(index);
            else if ("gemini".equals(type))  keyManager.removeGeminiKey(index);
            else                             keyManager.removeElevenLabsKey(index);
            refreshKeys(container, type);
        });
        row.addView(del);
        return row;
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private EditText addKeyInput(LinearLayout parent, String hint) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setTextColor(0xFFEBDBFF);
        et.setHintTextColor(0xFF8259A1);
        et.setBackgroundColor(0xFF0F0520);
        et.setPadding(20, 16, 20, 16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 4);
        et.setLayoutParams(lp);
        parent.addView(et);
        return et;
    }

    private void addHeader(LinearLayout parent, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(0xFFA129D1);
        tv.setTextSize(16);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 16, 0, 4);
        tv.setLayoutParams(lp);
        parent.addView(tv);
    }

    private void addHint(LinearLayout parent, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(0xFF8259A1);
        tv.setTextSize(12);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 8);
        tv.setLayoutParams(lp);
        parent.addView(tv);
    }

    private Button makeButton(String label, int color) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextColor(0xFFFFFFFF);
        btn.setBackgroundColor(color);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 100);
        lp.setMargins(0, 8, 0, 4);
        btn.setLayoutParams(lp);
        return btn;
    }

    private void addDivider(LinearLayout parent) {
        View v = new View(this);
        v.setBackgroundColor(0xFF4F1E6D);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 2);
        lp.setMargins(0, 16, 0, 16);
        v.setLayoutParams(lp);
        parent.addView(v);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        View focus = getCurrentFocus();
        if (focus != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
    }
}
