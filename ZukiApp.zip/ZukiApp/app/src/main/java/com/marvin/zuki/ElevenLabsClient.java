package com.marvin.zuki;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.util.Log;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

/**
 * ElevenLabs TTS client with API key rotation.
 * Keys are stored in KeyManager under "elevenlabs" type.
 * Falls back to Android TTS if no keys configured.
 */
public class ElevenLabsClient {

    private static final String TAG       = "ZukiElevenLabs";
    private static final String BASE_URL  = "https://api.elevenlabs.io/v1/text-to-speech/";
    private static final String MODEL     = "eleven_turbo_v2"; // fastest model

    // Default voice ID — change via Settings screen or update here
    public static final String DEFAULT_VOICE_ID = "0duPRxFCge5R3ZJInukg";

    private int  currentKeyIdx = 0;
    private int  retryCount    = 0;

    private final KeyManager keyManager;
    private final Context    ctx;

    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build();

    public interface Callback {
        void onAudioReady(File audioFile);
        void onError(String error);
        void onQuotaExceeded(String message); // rotate to next key
    }

    public ElevenLabsClient(Context ctx, KeyManager keyManager) {
        this.ctx        = ctx;
        this.keyManager = keyManager;
    }

    public boolean hasKeys() {
        return !keyManager.getElevenLabsKeys().isEmpty();
    }

    public String getVoiceId() {
        String saved = keyManager.getElevenLabsVoiceId();
        return (saved != null && !saved.isEmpty()) ? saved : DEFAULT_VOICE_ID;
    }

    public void speak(String text, Callback callback) {
        new Thread(() -> _doSpeak(text, callback)).start();
    }

    private void _doSpeak(String text, Callback callback) {
        List<String> keys = keyManager.getElevenLabsKeys();
        if (keys.isEmpty()) {
            callback.onError("No ElevenLabs keys configured");
            return;
        }
        if (currentKeyIdx >= keys.size()) currentKeyIdx = 0;

        try {
            String voiceId = getVoiceId();
            JSONObject body = new JSONObject()
                    .put("text", text)
                    .put("model_id", MODEL)
                    .put("voice_settings", new JSONObject()
                            .put("stability", 0.5)
                            .put("similarity_boost", 0.75)
                            .put("style", 0.3)
                            .put("use_speaker_boost", true));

            Request request = new Request.Builder()
                    .url(BASE_URL + voiceId)
                    .header("xi-api-key", keys.get(currentKeyIdx).trim())
                    .header("Content-Type", "application/json")
                    .header("Accept", "audio/mpeg")
                    .post(RequestBody.create(body.toString(),
                            MediaType.parse("application/json")))
                    .build();

            try (Response response = http.newCall(request).execute()) {
                if (response.code() == 401) {
                    // Bad key — try next
                    _rotateKey(text, callback, "Key " + (currentKeyIdx+1) + " invalid");
                    return;
                }
                if (response.code() == 429) {
                    // Quota exceeded — rotate
                    _rotateKey(text, callback, "Key " + (currentKeyIdx+1) + " quota exceeded");
                    return;
                }
                if (!response.isSuccessful() || response.body() == null) {
                    callback.onError("ElevenLabs HTTP " + response.code());
                    return;
                }

                // Save audio to temp file
                byte[] audioBytes = response.body().bytes();
                File tmpFile = new File(ctx.getCacheDir(), "zuki_tts_" + System.currentTimeMillis() + ".mp3");
                FileOutputStream fos = new FileOutputStream(tmpFile);
                fos.write(audioBytes);
                fos.close();

                retryCount = 0;
                callback.onAudioReady(tmpFile);
            }

        } catch (Exception e) {
            Log.e(TAG, "ElevenLabs error: " + e.getMessage());
            callback.onError(e.getMessage() != null ? e.getMessage() : "Unknown error");
        }
    }

    private void _rotateKey(String text, Callback callback, String reason) {
        List<String> keys = keyManager.getElevenLabsKeys();
        callback.onQuotaExceeded("⚠ " + reason + " — trying next key…");
        int nextIdx = (currentKeyIdx + 1) % keys.size();
        if (retryCount < keys.size()) {
            currentKeyIdx = nextIdx;
            retryCount++;
            _doSpeak(text, callback);
        } else {
            retryCount = 0;
            currentKeyIdx = 0;
            callback.onError("All ElevenLabs keys exhausted. Falling back to device TTS.");
        }
    }

    /**
     * Play an audio file and call onDone when finished.
     */
    public static void playAudio(File file, Runnable onDone) {
        try {
            MediaPlayer player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            player.setDataSource(file.getAbsolutePath());
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(mp -> {
                mp.release();
                file.delete(); // clean up temp file
                if (onDone != null) onDone.run();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                mp.release();
                file.delete();
                if (onDone != null) onDone.run();
                return true;
            });
            player.prepareAsync();
        } catch (Exception e) {
            Log.e(TAG, "Playback error: " + e.getMessage());
            file.delete();
            if (onDone != null) onDone.run();
        }
    }
}
