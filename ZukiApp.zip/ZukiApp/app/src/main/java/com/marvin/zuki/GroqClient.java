package com.marvin.zuki;

import org.json.*;
import okhttp3.*;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class GroqClient {

    private static final String GROQ_URL   = "https://api.groq.com/openai/v1/chat/completions";
    private static final String MODEL      = "llama-3.3-70b-versatile";
    private static final int    MAX_TOKENS = 1024;
    private static final int    MAX_TURNS  = 20;

    private int currentKeyIdx = 0;
    private int retryCount    = 0;

    private final KeyManager keyManager;

    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build();

    public interface Callback {
        void onResult(String reply);
        void onError(String error);
        void onRateLimit(String message);
    }

    public GroqClient(KeyManager keyManager) {
        this.keyManager = keyManager;
    }

    public void chat(List<Map<String, String>> history,
                     String systemPrompt,
                     Callback callback) {
        new Thread(() -> _doChat(history, systemPrompt, callback)).start();
    }

    private void _doChat(List<Map<String, String>> history,
                         String systemPrompt,
                         Callback callback) {
        List<String> keys = keyManager.getGroqKeys();

        if (keys.isEmpty()) {
            callback.onError("No Groq API keys configured. Add keys in Settings.");
            return;
        }

        if (currentKeyIdx >= keys.size()) currentKeyIdx = 0;

        try {
            JSONArray messages = new JSONArray();
            messages.put(new JSONObject().put("role", "system").put("content", systemPrompt));

            int start = Math.max(0, history.size() - MAX_TURNS * 2);
            for (int i = start; i < history.size(); i++) {
                Map<String, String> msg = history.get(i);
                String role = msg.get("role");
                if ("model".equals(role)) role = "assistant";
                messages.put(new JSONObject()
                        .put("role", role)
                        .put("content", msg.get("content")));
            }

            JSONObject body = new JSONObject()
                    .put("model", MODEL)
                    .put("messages", messages)
                    .put("max_tokens", MAX_TOKENS)
                    .put("temperature", 0.9);

            String currentKey = keys.get(currentKeyIdx).trim();
            android.util.Log.d("ZukiGroq", "Using key " + (currentKeyIdx+1)
                    + ": " + currentKey.substring(0, Math.min(12, currentKey.length()))
                    + "... length=" + currentKey.length());

            Request request = new Request.Builder()
                    .url(GROQ_URL)
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + currentKey)
                    .header("Accept", "application/json")
                    .post(RequestBody.create(body.toString(),
                            MediaType.parse("application/json")))
                    .build();

            try (Response response = http.newCall(request).execute()) {
                String responseBody = response.body() != null ? response.body().string() : "";

                if (response.code() == 429) {
                    int nextIdx = (currentKeyIdx + 1) % keys.size();
                    if (retryCount < keys.size()) {
                        currentKeyIdx = nextIdx;
                        retryCount++;
                        callback.onRateLimit("Rate limit — switching to key "
                                + (currentKeyIdx + 1) + "/" + keys.size() + "…");
                        _doChat(history, systemPrompt, callback);
                    } else if (retryCount < keys.size() + 3) {
                        currentKeyIdx = 0;
                        retryCount++;
                        int waitSec = (retryCount - keys.size()) * 5;
                        callback.onRateLimit("All keys limited — waiting " + waitSec + "s…");
                        Thread.sleep(waitSec * 1000L);
                        _doChat(history, systemPrompt, callback);
                    } else {
                        retryCount = 0;
                        currentKeyIdx = 0;
                        callback.onError("All keys rate limited. Add more keys in Settings.");
                    }
                    return;
                }

                if (!response.isSuccessful()) {
                    String errBody = responseBody.length() > 150
                            ? responseBody.substring(0, 150) : responseBody;
                    if (response.code() == 401) {
                        // Key is invalid — remove it and try next
                        callback.onRateLimit("Key " + (currentKeyIdx + 1) + " invalid (401) — trying next…");
                        currentKeyIdx = (currentKeyIdx + 1) % keys.size();
                        if (retryCount < keys.size()) {
                            retryCount++;
                            _doChat(history, systemPrompt, callback);
                        } else {
                            retryCount = 0;
                            callback.onError("All keys invalid. Please check keys in ⚙ Settings.");
                        }
                    } else {
                        callback.onError("HTTP " + response.code() + ": " + errBody);
                    }
                    return;
                }

                retryCount = 0;
                JSONObject json = new JSONObject(responseBody);
                String reply = json.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                        .trim();
                callback.onResult(reply);
            }

        } catch (Exception e) {
            callback.onError(e.getMessage() != null ? e.getMessage() : "Unknown error");
        }
    }
}
