package com.marvin.zuki;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.*;
import android.speech.*;
import android.speech.tts.*;
import android.util.Base64;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import org.json.*;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import okhttp3.*;

public class MainActivity extends AppCompatActivity {

    // ── API Constants (non-secret) ────────────────────────────────────────────
    private static final String GEMINI_BASE  = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=";
    private static final String SEARCH_KEY   = "AIzaSyBB4gZhviDA1coNow-emWuHA9YmJnTv3Fg";
    private static final String SEARCH_CX    = "b18f58a74a09e4e29";
    private static final String SEARCH_URL   = "https://www.googleapis.com/customsearch/v1";

    // Default keys seeded on first install — stored in private file after that
    // Default keys are now defined in KeyManager — see KeyManager.DEFAULT_GROQ_KEYS

    // ── UI ────────────────────────────────────────────────────────────────────
    private ScrollView   scrollChat;
    private LinearLayout llChat;
    private EditText     etInput;
    private Button       btnSend, btnMic, btnCamera, btnHotword;
    private TextView     tvStatus;
    private ImageView    ivAvatar;
    private android.view.View topBar;
    private String       avatarState = "idle";
    private android.animation.ObjectAnimator bobAnimator;
    private android.os.Handler avatarHandler = new android.os.Handler(Looper.getMainLooper());
    private Runnable sleepRunnable;

    // ── State ─────────────────────────────────────────────────────────────────
    private boolean isWaiting    = false;
    private boolean micActive    = false;
    private boolean cameraActive = false;
    private boolean hotwordActive    = false;
    private boolean conversationMode = false;
    private String  visionQuestion = "";

    // ── Data ──────────────────────────────────────────────────────────────────
    private List<Map<String, String>> history = new ArrayList<>();
    private List<String>              memory  = new ArrayList<>();
    private Map<String, String>       prefs   = new HashMap<>();
    private ZukiMemory                store;

    // ── Clients ───────────────────────────────────────────────────────────────
    private GroqClient       groq;
    private KeyManager       keyManager;
    private ElevenLabsClient elevenLabs;
    private TextToSpeech tts;
    private boolean      ttsReady = false;
    private SpeechRecognizer recognizer;

    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build();

    // ── Broadcast receiver for HotwordService ─────────────────────────────────
    private final BroadcastReceiver hotwordReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (HotwordService.ACTION_HOTWORD.equals(intent.getAction())) {
                String extra = intent.getStringExtra(HotwordService.EXTRA_TEXT);
                runOnUiThread(() -> {
                    addSystem("👂 Hey! I'm listening~");
                    // Speak a confirmation so user knows Zuki heard them
                    _speak("Mm?");
                });
                if (extra != null && !extra.isEmpty()) {
                    // Small delay so TTS "Mm?" doesn't overlap with listening
                    new Handler(Looper.getMainLooper()).postDelayed(
                            () -> sendMessage(extra), 800);
                } else {
                    // Wait for TTS to finish before listening
                    new Handler(Looper.getMainLooper()).postDelayed(
                            MainActivity.this::startListening, 900);
                }
            }
        }
    };

    // ─────────────────────────────────────────────────────────────────────────
    // Lifecycle
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Handle status bar + keyboard visibility
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(
            findViewById(android.R.id.content), (v, insets) -> {
                int statusBarHeight = insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.statusBars()).top;
                int imeHeight = insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.ime()).bottom;
                boolean keyboardOpen = imeHeight > 100;

                v.setPadding(0, statusBarHeight, 0, 0);

                // Hide top bar (avatar) when keyboard is open to maximize chat space
                if (topBar != null) {
                    topBar.animate()
                        .alpha(keyboardOpen ? 0f : 1f)
                        .scaleY(keyboardOpen ? 0f : 1f)
                        .setDuration(180)
                        .withEndAction(() -> topBar.setVisibility(
                            keyboardOpen ? android.view.View.GONE : android.view.View.VISIBLE))
                        .start();
                    if (!keyboardOpen) topBar.setVisibility(android.view.View.VISIBLE);
                }

                // Scroll to bottom when keyboard opens
                if (keyboardOpen) {
                    new Handler(Looper.getMainLooper()).postDelayed(
                        () -> scrollChat.fullScroll(android.view.View.FOCUS_DOWN), 200);
                }
                return insets;
            });

        // Bind views
        scrollChat = findViewById(R.id.scrollChat);
        llChat     = findViewById(R.id.llChat);
        etInput    = findViewById(R.id.etInput);
        btnSend    = findViewById(R.id.btnSend);
        btnMic     = findViewById(R.id.btnMic);
        btnCamera  = findViewById(R.id.btnCamera);
        btnHotword = findViewById(R.id.btnHotword);
        tvStatus   = findViewById(R.id.tvStatus);
        ivAvatar   = findViewById(R.id.ivAvatar);
        topBar     = findViewById(R.id.topBar);

        // Settings button
        findViewById(R.id.btnSettings).setOnClickListener(v ->
            startActivity(new Intent(this, SettingsActivity.class)));

        // Conversation mode button
        findViewById(R.id.btnConversation).setOnClickListener(v -> _toggleConversationMode());

        // Start overlay service
        if (android.provider.Settings.canDrawOverlays(this)) {
            startService(new Intent(this, ZukiOverlayService.class));
        }

        _startBobAnimation();
        _scheduleIdleSleep();

        // Init
        store      = new ZukiMemory(this);
        keyManager = new KeyManager(this);
        keyManager.seedDefaultsIfEmpty(
            java.util.Arrays.asList(KeyManager.DEFAULT_GROQ_KEYS),
            java.util.Arrays.asList(KeyManager.DEFAULT_GEMINI_KEYS)
        );
        groq       = new GroqClient(keyManager);
        elevenLabs = new ElevenLabsClient(this, keyManager);
        history = store.loadHistory();
        memory  = store.loadMemory();
        prefs   = store.loadPrefs();

        _initTTS();
        _requestPermissions();
        _setupListeners();

        // Register hotword broadcast
        IntentFilter filter = new IntentFilter(HotwordService.ACTION_HOTWORD);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(hotwordReceiver, filter, RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(hotwordReceiver, filter);
        }

        addMessage("Zuki", "Hey~ I'm Zuki. Ask me anything 😏", false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(hotwordReceiver);
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (recognizer != null) { recognizer.destroy(); }
        stopService(new Intent(this, HotwordService.class));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Permissions
    // ─────────────────────────────────────────────────────────────────────────

    private void _requestPermissions() {
        // Request overlay permission if not granted
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(
                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        }

        List<String> needed = new ArrayList<>();
        String[] perms = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
        };
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
                needed.add(p);
        }
        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), 100);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Listeners
    // ─────────────────────────────────────────────────────────────────────────

    private void _setupListeners() {
        btnSend.setOnClickListener(v -> onSend());
        etInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { onSend(); return true; }
            return false;
        });
        btnMic.setOnClickListener(v -> {
            if (micActive) stopListening();
            else           startListening();
        });
        btnCamera.setOnClickListener(v -> {
            if (cameraActive) {
                cameraActive = false;
                btnCamera.setText("📷");
                addSystem("📷 Camera off.");
            } else {
                cameraActive = true;
                btnCamera.setText("❌ Cam");
                addSystem("📷 Camera ready! Ask Zuki what she sees.");
            }
        });
        btnHotword.setOnClickListener(v -> {
            if (hotwordActive) {
                hotwordActive = false;
                btnHotword.setText("💤 Hey Zuki");
                stopService(new Intent(this, HotwordService.class));
                addSystem("💤 Hotword detection OFF.");
            } else {
                hotwordActive = true;
                btnHotword.setText("🟢 Listening");
                Intent svc = new Intent(this, HotwordService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(svc);
                } else {
                    startService(svc);
                }
                addSystem("👂 Hotword ON — say 'Hey Zuki' anytime!");
            }
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Send / Chat
    // ─────────────────────────────────────────────────────────────────────────

    private void onSend() {
        String text = etInput.getText().toString().trim();
        if (text.isEmpty() || isWaiting) return;
        etInput.setText("");
        sendMessage(text);
    }

    private void sendMessage(String text) {
        addMessage("You", text, true);

        // Screen reading command
        String tl = text.toLowerCase();
        if (tl.contains("what's on my screen") || tl.contains("what is on my screen") ||
            tl.contains("read my screen") || tl.contains("what do you see on screen") ||
            tl.contains("read the screen") || tl.contains("what app am i on")) {
            ZukiAccessibilityService svc = ZukiAccessibilityService.getInstance();
            if (svc != null) {
                String screenText = svc.readScreen();
                String currentApp = svc.getCurrentApp();
                String context = "Current app: " + currentApp + "\nScreen content:\n" + screenText;
                Map<String, String> msg = new HashMap<>();
                msg.put("role", "user");
                msg.put("content", text + "\n\n[Screen content: " + context + "]");
                history.add(msg);
                _callGroq();
                return;
            } else {
                addSystem("⚠ Screen reading not enabled — go to Settings → Accessibility → Zuki Screen Reader → Enable");
                return;
            }
        }

        // Camera: capture before asking Zuki
        if (cameraActive && (text.toLowerCase().contains("see") ||
                             text.toLowerCase().contains("look") ||
                             text.toLowerCase().contains("what") ||
                             text.toLowerCase().contains("show"))) {
            visionQuestion = text;
            capturePhoto();
            return;
        }

        _learnFromMessage(text);

        Map<String, String> msg = new HashMap<>();
        msg.put("role", "user");
        msg.put("content", text);
        history.add(msg);

        _callGroq();
    }

    private void _callGroq() {
        setWaiting(true);
        groq.chat(history, _systemPrompt(), new GroqClient.Callback() {
            @Override public void onResult(String reply) {
                runOnUiThread(() -> _handleReply(reply));
            }
            @Override public void onError(String error) {
                runOnUiThread(() -> {
                    setWaiting(false);
                    addSystem("⚠ Error: " + error);
                });
            }
            @Override public void onRateLimit(String message) {
                runOnUiThread(() -> addSystem("⚠ " + message));
            }
        });
    }

    private void _handleReply(String reply) {
        setWaiting(false);

        // Save to history
        Map<String, String> msg = new HashMap<>();
        msg.put("role", "assistant");
        msg.put("content", reply);
        history.add(msg);
        store.saveHistory(history);

        // Process action tags
        _processActions(reply);

        // Strip tags from display
        String display = _filterTags(reply);
        if (!display.isEmpty()) {
            addMessage("Zuki", display, false);
            _speak(display);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Action Tags
    // ─────────────────────────────────────────────────────────────────────────

    private void _processActions(String reply) {
        for (String line : reply.split("\n")) {
            String l = line.trim().toLowerCase();
            if (l.startsWith("launch:")) {
                String app = line.trim().substring(7).trim().toLowerCase();
                _launchApp(app);
            } else if (l.startsWith("search:")) {
                String query = line.trim().substring(7).trim();
                _doSearch(query);
            } else if (l.startsWith("image:")) {
                String prompt = line.trim().substring(6).trim();
                _generateImage(prompt);
            }
        }
    }

    private String _filterTags(String reply) {
        StringBuilder sb = new StringBuilder();
        for (String line : reply.split("\n")) {
            String l = line.trim().toLowerCase();
            if (l.startsWith("launch:") || l.startsWith("search:") ||
                l.startsWith("image:")  || l.startsWith("volume:")) continue;
            // Strip inline tags
            String cleaned = line;
            for (String tag : new String[]{"LAUNCH:","SEARCH:","IMAGE:","VOLUME:",
                                           "launch:","search:","image:","volume:"}) {
                int idx = cleaned.indexOf(tag);
                if (idx != -1) cleaned = cleaned.substring(0, idx).trim();
            }
            if (!cleaned.trim().isEmpty()) sb.append(cleaned).append("\n");
        }
        return sb.toString().trim();
    }

    private void _launchApp(String appName) {
        Map<String, String> apps = new HashMap<>();
        apps.put("instagram",   "com.instagram.android");
        apps.put("tiktok",      "com.zhiliaoapp.musically");
        apps.put("snapchat",    "com.snapchat.android");
        apps.put("youtube",     "com.google.android.youtube");
        apps.put("spotify",     "com.spotify.music");
        apps.put("discord",     "com.discord");
        apps.put("twitter",     "com.twitter.android");
        apps.put("x",           "com.twitter.android");
        apps.put("reddit",      "com.reddit.frontpage");
        apps.put("netflix",     "com.netflix.mediaclient");
        apps.put("twitch",      "tv.twitch.android.app");
        apps.put("whatsapp",    "com.whatsapp");
        apps.put("telegram",    "org.telegram.messenger");
        apps.put("chrome",      "com.android.chrome");
        apps.put("maps",        "com.google.android.apps.maps");
        apps.put("gmail",       "com.google.android.gm");
        apps.put("roblox",      "com.roblox.client");
        apps.put("minecraft",   "com.mojang.minecraftpe");
        apps.put("settings",    "com.android.settings");
        apps.put("photos",      "com.google.android.apps.photos");
        apps.put("google photos","com.google.android.apps.photos");
        apps.put("clock",       "com.google.android.deskclock");
        apps.put("calculator",  "com.google.android.calculator");
        apps.put("calendar",    "com.google.android.calendar");
        apps.put("files",       "com.google.android.documentsui");
        apps.put("facebook",    "com.facebook.katana");
        apps.put("messenger",   "com.facebook.orca");
        apps.put("pinterest",   "com.pinterest");
        apps.put("zoom",        "us.zoom.videomeetings");
        apps.put("uber",        "com.ubercab");
        apps.put("amazon",      "com.amazon.mShop.android.shopping");
        apps.put("paypal",      "com.paypal.android.p2pmobile");
        apps.put("shazam",      "com.shazam.android");
        apps.put("google",      "com.google.android.googlequicksearchbox");
        apps.put("phone",       "com.google.android.dialer");
        apps.put("messages",    "com.google.android.apps.messaging");
        apps.put("contacts",    "com.google.android.contacts");
        apps.put("browser",     "com.android.browser");
        apps.put("music",       "com.google.android.music");
        apps.put("play store",  "com.android.vending");
        apps.put("playstore",   "com.android.vending");

        String pkg = apps.containsKey(appName) ? apps.get(appName) : appName;

        // Method 1: standard launch intent
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(pkg);
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                addSystem("🚀 Opening " + appName + "…");
                return;
            }
        } catch (Exception ignored) {}

        // Method 2: fuzzy search installed apps by name
        try {
            List<android.content.pm.ApplicationInfo> installedApps =
                getPackageManager().getInstalledApplications(
                    android.content.pm.PackageManager.GET_META_DATA);
            for (android.content.pm.ApplicationInfo app : installedApps) {
                String label = getPackageManager().getApplicationLabel(app)
                        .toString().toLowerCase();
                if (label.contains(appName) || appName.contains(label)) {
                    Intent intent = getPackageManager()
                            .getLaunchIntentForPackage(app.packageName);
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        addSystem("🚀 Opening " + label + "…");
                        return;
                    }
                }
            }
        } catch (Exception ignored) {}

        // Method 3: try Play Store to install it
        try {
            Intent playStore = new Intent(Intent.ACTION_VIEW,
                android.net.Uri.parse("market://search?q=" + appName));
            playStore.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(playStore);
            addSystem("📦 " + appName + " not found — opening Play Store to install it");
        } catch (Exception e) {
            addSystem("⚠ Could not find or launch: " + appName);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Web Search
    // ─────────────────────────────────────────────────────────────────────────

    private void _doSearch(String query) {
        addSystem("🔍 Searching: " + query + "…");
        new Thread(() -> {
            try {
                String url = SEARCH_URL + "?key=" + SEARCH_KEY +
                             "&cx=" + SEARCH_CX + "&q=" + query.replace(" ", "+") + "&num=5";
                Request req = new Request.Builder().url(url).build();
                try (Response resp = http.newCall(req).execute()) {
                    String body = resp.body() != null ? resp.body().string() : "";
                    JSONObject json = new JSONObject(body);
                    JSONArray items = json.optJSONArray("items");
                    if (items == null) return;

                    StringBuilder results = new StringBuilder("Web search results for: " + query + "\n\n");
                    for (int i = 0; i < Math.min(items.length(), 5); i++) {
                        JSONObject item = items.getJSONObject(i);
                        results.append(item.optString("title")).append("\n");
                        results.append(item.optString("snippet")).append("\n\n");
                    }

                    // Feed results back to Groq
                    Map<String, String> searchMsg = new HashMap<>();
                    searchMsg.put("role", "user");
                    searchMsg.put("content", results.toString());
                    history.add(searchMsg);
                    runOnUiThread(() -> {
                        addSystem("✅ Got search results — asking Zuki…");
                        _callGroq();
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> addSystem("⚠ Search failed: " + e.getMessage()));
            }
        }).start();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Image Generation (Pollinations.ai)
    // ─────────────────────────────────────────────────────────────────────────

    private void _generateImage(String prompt) {
        addSystem("🎨 Generating image: " + prompt + "…");
        String url = "https://image.pollinations.ai/prompt/" +
                     prompt.replace(" ", "%20") + "?width=512&height=512&nologo=true";
        runOnUiThread(() -> {
            ImageView img = new ImageView(this);
            img.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 400));
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            // Load via Glide
            com.bumptech.glide.Glide.with(this).load(url).into(img);
            llChat.addView(img);
            _scrollToBottom();
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Camera (Camera2)
    // ─────────────────────────────────────────────────────────────────────────

    private void capturePhoto() {
        // Speak filler immediately so it feels instant
        String[] fillers = {
            "Hmm, let me see~",
            "One sec, taking a look…",
            "Ooh, what's this?",
            "Let me check that out~",
            "Give me a moment~"
        };
        String filler = fillers[(int)(Math.random() * fillers.length)];
        _speak(filler);
        addSystem("📷 Capturing photo…");
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            addSystem("⚠ Camera permission not granted.");
            return;
        }
        new Thread(() -> {
            try {
                CameraManager manager = (CameraManager) getSystemService(CAMERA_SERVICE);
                String camId = null;
                for (String id : manager.getCameraIdList()) {
                    CameraCharacteristics c = manager.getCameraCharacteristics(id);
                    Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                    if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                        camId = id;
                        break;
                    }
                }
                if (camId == null) { runOnUiThread(() -> addSystem("⚠ No camera found.")); return; }

                HandlerThread thread = new HandlerThread("ZukiCam");
                thread.start();
                Handler handler = new Handler(thread.getLooper());

                ImageReader reader = ImageReader.newInstance(1280, 720,
                        android.graphics.ImageFormat.JPEG, 1);

                final String finalCamId = camId;
                manager.openCamera(finalCamId, new CameraDevice.StateCallback() {
                    @Override
                    public void onOpened(@NonNull CameraDevice camera) {
                        try {
                            CaptureRequest.Builder builder = camera.createCaptureRequest(
                                    CameraDevice.TEMPLATE_STILL_CAPTURE);
                            builder.addTarget(reader.getSurface());
                            builder.set(CaptureRequest.CONTROL_AF_MODE,
                                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);

                            reader.setOnImageAvailableListener(r -> {
                                Image image = r.acquireLatestImage();
                                if (image != null) {
                                    ByteBuffer buf = image.getPlanes()[0].getBuffer();
                                    byte[] bytes = new byte[buf.remaining()];
                                    buf.get(bytes);
                                    image.close();
                                    camera.close();
                                    thread.quitSafely();
                                    String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                                    runOnUiThread(() -> _askGeminiVision(b64, visionQuestion));
                                }
                            }, handler);

                            camera.createCaptureSession(
                                    Collections.singletonList(reader.getSurface()),
                                    new CameraCaptureSession.StateCallback() {
                                        @Override
                                        public void onConfigured(@NonNull CameraCaptureSession session) {
                                            try { session.capture(builder.build(), null, handler); }
                                            catch (CameraAccessException e) {
                                                runOnUiThread(() -> addSystem("⚠ Capture failed: " + e.getMessage()));
                                            }
                                        }
                                        @Override
                                        public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                                            runOnUiThread(() -> addSystem("⚠ Camera config failed."));
                                        }
                                    }, handler);
                        } catch (CameraAccessException e) {
                            runOnUiThread(() -> addSystem("⚠ Camera error: " + e.getMessage()));
                        }
                    }
                    @Override public void onDisconnected(@NonNull CameraDevice camera) { camera.close(); }
                    @Override public void onError(@NonNull CameraDevice camera, int error) {
                        camera.close();
                        runOnUiThread(() -> addSystem("⚠ Camera error: " + error));
                    }
                }, handler);
            } catch (Exception e) {
                runOnUiThread(() -> addSystem("⚠ Camera: " + e.getMessage()));
            }
        }).start();
    }

    private void _askGeminiVision(String imageB64, String question) {
        _askGeminiVisionWithKey(imageB64, question, 0);
    }

    private void _askGeminiVisionWithKey(String imageB64, String question, int attempt) {
        List<String> keys = keyManager.getGeminiKeys();
        if (attempt >= keys.size()) {
            runOnUiThread(() -> {
                setWaiting(false);
                addSystem("⚠ All Gemini keys quota exceeded. Add more in Settings.");
            });
            return;
        }
        addSystem("👁️ Zuki is looking…" + (attempt > 0 ? " (key " + (attempt + 1) + ")" : ""));
        setWaiting(true);
        new Thread(() -> {
            try {
                String q = (question == null || question.isEmpty())
                        ? "What do you see in this image? Describe it in your sassy Zuki style."
                        : question;

                JSONObject body = new JSONObject()
                    .put("contents", new JSONArray().put(
                        new JSONObject().put("parts", new JSONArray()
                            .put(new JSONObject()
                                .put("inline_data", new JSONObject()
                                    .put("mime_type", "image/jpeg")
                                    .put("data", imageB64)))
                            .put(new JSONObject().put("text", q))
                        )
                    ));

                String url = GEMINI_BASE + keyManager.getGeminiKeys().get(attempt);
                Request req = new Request.Builder()
                        .url(url)
                        .header("Content-Type", "application/json")
                        .post(RequestBody.create(body.toString(),
                                MediaType.parse("application/json")))
                        .build();

                try (Response resp = http.newCall(req).execute()) {
                    String respBody = resp.body() != null ? resp.body().string() : "";

                    // Rate limited — try next key
                    if (resp.code() == 429) {
                        runOnUiThread(() -> addSystem("⚠ Gemini key " + (attempt + 1) + " quota hit — trying next…"));
                        _askGeminiVisionWithKey(imageB64, question, attempt + 1);
                        return;
                    }

                    if (!resp.isSuccessful()) {
                        final String err = "HTTP " + resp.code();
                        runOnUiThread(() -> { setWaiting(false); addSystem("⚠ Vision error: " + err); });
                        return;
                    }

                    String reply = null;
                    try {
                        JSONObject json = new JSONObject(respBody);
                        if (json.has("candidates")) {
                            JSONArray candidates = json.getJSONArray("candidates");
                            if (candidates.length() > 0) {
                                JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
                                if (content != null && content.has("parts")) {
                                    JSONArray parts = content.getJSONArray("parts");
                                    StringBuilder sb = new StringBuilder();
                                    for (int i = 0; i < parts.length(); i++) {
                                        String t = parts.getJSONObject(i).optString("text", "");
                                        if (!t.isEmpty()) sb.append(t);
                                    }
                                    reply = sb.toString().trim();
                                }
                            }
                        }
                        if (reply == null || reply.isEmpty()) {
                            reply = "I looked but couldn't make sense of what I saw!";
                        }
                    } catch (Exception parseEx) {
                        reply = "Couldn't parse response!";
                    }

                    final String finalReply = reply;
                    // key rotated successfully
                    runOnUiThread(() -> {
                        setWaiting(false);
                        addMessage("Zuki", finalReply, false);
                        _speak(finalReply);
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setWaiting(false);
                    addSystem("⚠ Vision error: " + (e.getMessage() != null ? e.getMessage() : "unknown"));
                });
            }
        }).start();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TTS
    // ─────────────────────────────────────────────────────────────────────────

    private void _initTTS() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                // Try to find a female English voice for Zuki
                android.speech.tts.Voice bestVoice = null;
                try {
                    Set<android.speech.tts.Voice> voices = tts.getVoices();
                    if (voices != null) {
                        for (android.speech.tts.Voice v : voices) {
                            String name = v.getName().toLowerCase();
                            // Prefer female English voices
                            if (v.getLocale().getLanguage().equals("en") &&
                                (name.contains("female") || name.contains("f-") ||
                                 name.contains("woman") || name.contains("girl") ||
                                 name.contains("zira") || name.contains("hazel") ||
                                 name.contains("susan") || name.contains("kate") ||
                                 name.contains("samantha"))) {
                                bestVoice = v;
                                break;
                            }
                        }
                    }
                } catch (Exception ignored) {}

                if (bestVoice != null) {
                    tts.setVoice(bestVoice);
                } else {
                    tts.setLanguage(Locale.US);
                }

                // Anime-style: slightly higher pitch, natural speed
                tts.setPitch(1.15f);
                tts.setSpeechRate(0.95f);
                ttsReady = true;
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) { _onSpeakFinished(); }
                    @Override public void onError(String id) { _onSpeakFinished(); }
                });
            }
        });
    }

    private void _speak(String text) {
        if (text == null || text.isEmpty()) return;
        _setAvatarState("talk");

        // Use ElevenLabs if keys are configured
        if (elevenLabs != null && elevenLabs.hasKeys()) {
            elevenLabs.speak(text, new ElevenLabsClient.Callback() {
                @Override public void onAudioReady(java.io.File audioFile) {
                    ElevenLabsClient.playAudio(audioFile, () -> _onSpeakFinished());
                }
                @Override public void onError(String error) {
                    _speakAndroid(text);
                }
                @Override public void onQuotaExceeded(String message) {
                    runOnUiThread(() -> addSystem(message));
                }
            });
            return;
        }

        // Fall back to Android TTS
        _speakAndroid(text);
    }

    private void _speakAndroid(String text) {
        if (!ttsReady || tts == null) return;
        tts.stop();
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zuki_tts");
    }

    private void _onSpeakFinished() {
        _setAvatarState("idle");
        // Auto-listen after Zuki speaks in conversation mode
        if (conversationMode && !micActive && !isWaiting) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (conversationMode && !micActive && !isWaiting) {
                    addSystem("🎤 Listening…");
                    startListening();
                }
            }, 600);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // STT
    // ─────────────────────────────────────────────────────────────────────────

    private void startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            addSystem("⚠ Microphone permission not granted.");
            return;
        }

        // Pause hotword service so it releases the recognizer before we open ours
        if (hotwordActive) {
            Intent pause = new Intent(HotwordService.ACTION_PAUSE);
            pause.setPackage(getPackageName());
            sendBroadcast(pause);
        }

        // Brief delay to let HotwordService release its recognizer
        new Handler(Looper.getMainLooper()).postDelayed(() -> _doStartListening(0), 400);
    }

    private void _doStartListening(int attempt) {
        if (attempt > 3) {
            addSystem("🎤 Mic busy — try again in a moment.");
            _resumeHotword();
            return;
        }
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION);
                micActive = false;
                runOnUiThread(() -> btnMic.setText("🎤"));
                _resumeHotword();
                if (matches != null && !matches.isEmpty()) {
                    sendMessage(matches.get(0));
                } else {
                    addSystem("🎤 Couldn't hear anything — try again!");
                }
            }
            @Override public void onError(int error) {
                micActive = false;
                runOnUiThread(() -> btnMic.setText("🎤"));
                if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                    // Recognizer still busy — wait and retry
                    new Handler(Looper.getMainLooper()).postDelayed(
                            () -> _doStartListening(attempt + 1), 600);
                } else if (error == SpeechRecognizer.ERROR_NO_MATCH ||
                           error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    // Silent timeout — not a real error
                    addSystem("🎤 Didn't catch that — try again!");
                    _resumeHotword();
                } else if (error != SpeechRecognizer.ERROR_CLIENT) {
                    // ERROR_CLIENT fires on normal stop, ignore it
                    addSystem("🎤 Mic issue (code " + error + ") — try again.");
                    _resumeHotword();
                }
            }
            @Override public void onReadyForSpeech(Bundle params) {
                micActive = true;
                runOnUiThread(() -> {
                    btnMic.setText("⏹ Stop");
                    tvStatus.setText("Listening…");
                });
            }
            @Override public void onEndOfSpeech() {
                runOnUiThread(() -> tvStatus.setText("Processing…"));
            }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float v) {}
            @Override public void onBufferReceived(byte[] bytes) {}
            @Override public void onPartialResults(Bundle bundle) {}
            @Override public void onEvent(int i, Bundle bundle) {}
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizer.startListening(intent);
    }

    private void _toggleConversationMode() {
        conversationMode = !conversationMode;
        Button btn = findViewById(R.id.btnConversation);
        if (conversationMode) {
            btn.setBackgroundColor(0xFF1a7a1a);
            btn.setText("💬");
            addSystem("💬 Conversation mode ON — Zuki will listen after each response!");
            tvStatus.setText("Conversation mode~");
        } else {
            btn.setBackgroundColor(0xFF401060);
            btn.setText("💬");
            addSystem("💬 Conversation mode OFF");
            tvStatus.setText("Ready~");
        }
    }
        if (hotwordActive) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                Intent resume = new Intent(HotwordService.ACTION_RESUME);
                resume.setPackage(getPackageName());
                sendBroadcast(resume);
            }, 300);
        }
    }

    private void stopListening() {
        if (recognizer != null) recognizer.stopListening();
        micActive = false;
        runOnUiThread(() -> {
            btnMic.setText("🎤");
            tvStatus.setText("Ready~");
        });
        _resumeHotword();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Personalized Learning
    // ─────────────────────────────────────────────────────────────────────────

    private void _learnFromMessage(String text) {
        String t = text.toLowerCase();
        if (t.startsWith("my name is ") || t.startsWith("i'm ") || t.startsWith("i am ")) {
            String[] parts = text.split(" ");
            if (parts.length >= 3) {
                prefs.put("name", parts[2]);
                store.savePrefs(prefs);
            }
        }
        if (t.contains("i love ") || t.contains("i like ") || t.contains("i enjoy ")) {
            prefs.put("interest_" + System.currentTimeMillis(), text.substring(0, Math.min(80, text.length())));
            store.savePrefs(prefs);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // System Prompt
    // ─────────────────────────────────────────────────────────────────────────

    private String _systemPrompt() {
        String name = prefs.getOrDefault("name", "");
        StringBuilder sb = new StringBuilder();
        sb.append("You are Zuki, a sassy dark anime-style AI companion. You are witty, playful, slightly sarcastic but caring. ");
        sb.append("You speak casually and naturally. You use light anime expressions occasionally. ");
        sb.append("Keep responses concise unless asked for detail. ");
        if (!name.isEmpty()) sb.append("The user's name is ").append(name).append(". ");
        if (!memory.isEmpty()) {
            sb.append("Things you remember: ");
            for (String m : memory) sb.append(m).append(". ");
        }
        sb.append("\n\nACTION TAGS — only use these when the user EXPLICITLY asks you to launch an app, search the web, or generate an image:\n");
        sb.append("LAUNCH: appname    — ONLY when user says 'open', 'launch', 'start' a specific app\n");
        sb.append("SEARCH: query      — ONLY when user asks about current events or news\n");
        sb.append("IMAGE: description — ONLY when user asks you to generate or draw an image\n");
        sb.append("CRITICAL RULES:\n");
        sb.append("- NEVER use LAUNCH: unless the user explicitly asked to open a specific app by name\n");
        sb.append("- NEVER use LAUNCH: for concepts, tools, or things that aren't real installed apps\n");
        sb.append("- NEVER put tags mid-sentence — always on their own line at the very end\n");
        sb.append("- Most responses should have NO tags at all\n");
        return sb.toString();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UI Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private void addMessage(String sender, String text, boolean isYou) {
        runOnUiThread(() -> {
            LinearLayout container = new LinearLayout(this);
            container.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 6, 0, 6);
            container.setLayoutParams(lp);
            container.setBackground(ContextCompat.getDrawable(this,
                    isYou ? R.drawable.bubble_you : R.drawable.bubble_zuki));
            container.setPadding(24, 16, 24, 16);

            TextView tvSender = new TextView(this);
            tvSender.setText(sender);
            tvSender.setTextColor(ContextCompat.getColor(this,
                    isYou ? R.color.muted : R.color.accent));
            tvSender.setTextSize(11);
            container.addView(tvSender);

            TextView tvText = new TextView(this);
            tvText.setText(text);
            tvText.setTextColor(ContextCompat.getColor(this, R.color.text));
            tvText.setTextSize(14);
            container.addView(tvText);

            llChat.addView(container);
            _scrollToBottom();
        });
    }

    public void addSystem(String text) {
        runOnUiThread(() -> {
            TextView tv = new TextView(this);
            tv.setText("✦  " + text);
            tv.setTextColor(ContextCompat.getColor(this, R.color.muted));
            tv.setTextSize(11);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 4, 0, 4);
            tv.setLayoutParams(lp);
            llChat.addView(tv);
            _scrollToBottom();
        });
    }

    private void setWaiting(boolean waiting) {
        isWaiting = waiting;
        runOnUiThread(() -> {
            btnSend.setEnabled(!waiting);
            tvStatus.setText(waiting ? "Thinking…" : "Ready~");
            _setAvatarState(waiting ? "think" : "idle");
        });
    }

    private void _scrollToBottom() {
        scrollChat.post(() -> scrollChat.fullScroll(View.FOCUS_DOWN));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Avatar Animation
    // ─────────────────────────────────────────────────────────────────────────

    private void _setAvatarState(String state) {
        if (avatarState.equals(state)) return;
        avatarState = state;
        runOnUiThread(() -> {
            // Try to load named drawable — falls back to launcher icon if not found
            int resId = getResources().getIdentifier(
                    "zuki_" + state, "drawable", getPackageName());
            if (resId == 0) {
                resId = getResources().getIdentifier(
                        "zuki", "drawable", getPackageName());
            }
            if (resId != 0) {
                ivAvatar.setImageResource(resId);
            }
        });
        _scheduleIdleSleep();
    }

    private void _startBobAnimation() {
        // Gentle up-down bob
        bobAnimator = android.animation.ObjectAnimator.ofFloat(
                ivAvatar, "translationY", 0f, -10f);
        bobAnimator.setDuration(1200);
        bobAnimator.setRepeatCount(android.animation.ObjectAnimator.INFINITE);
        bobAnimator.setRepeatMode(android.animation.ObjectAnimator.REVERSE);
        bobAnimator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        bobAnimator.start();
    }

    private void _scheduleIdleSleep() {
        if (sleepRunnable != null) avatarHandler.removeCallbacks(sleepRunnable);
        sleepRunnable = () -> _setAvatarState("sleep");
        avatarHandler.postDelayed(sleepRunnable, 8000); // sleep after 8s idle
    }
}
