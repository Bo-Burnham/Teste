package com.marvin.zuki;

import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.util.*;

public class ZukiMemory {
    private static final String HISTORY_FILE = "history.json";
    private static final String MEMORY_FILE  = "memory.json";
    private static final String PREFS_FILE   = "prefs.json";
    private static final long   MAX_HISTORY_BYTES = 100 * 1024 * 1024; // 100MB

    private final Context ctx;
    private final Gson    gson = new Gson();

    public ZukiMemory(Context ctx) { this.ctx = ctx; }

    // ── History ───────────────────────────────────────────────────────────────

    public List<Map<String, String>> loadHistory() {
        String json = readFile(HISTORY_FILE);
        if (json == null) return new ArrayList<>();
        Type type = new TypeToken<List<Map<String, String>>>(){}.getType();
        List<Map<String, String>> list = gson.fromJson(json, type);
        return list != null ? list : new ArrayList<>();
    }

    public void saveHistory(List<Map<String, String>> history) {
        String json = gson.toJson(history);
        // Trim if too large
        while (json.getBytes().length > MAX_HISTORY_BYTES && !history.isEmpty()) {
            history.remove(0);
            json = gson.toJson(history);
        }
        writeFile(HISTORY_FILE, json);
    }

    // ── Memory ────────────────────────────────────────────────────────────────

    public List<String> loadMemory() {
        String json = readFile(MEMORY_FILE);
        if (json == null) return new ArrayList<>();
        Type type = new TypeToken<List<String>>(){}.getType();
        List<String> list = gson.fromJson(json, type);
        return list != null ? list : new ArrayList<>();
    }

    public void saveMemory(List<String> memory) {
        writeFile(MEMORY_FILE, gson.toJson(memory));
    }

    // ── Prefs ─────────────────────────────────────────────────────────────────

    public Map<String, String> loadPrefs() {
        String json = readFile(PREFS_FILE);
        if (json == null) return new HashMap<>();
        Type type = new TypeToken<Map<String, String>>(){}.getType();
        Map<String, String> map = gson.fromJson(json, type);
        return map != null ? map : new HashMap<>();
    }

    public void savePrefs(Map<String, String> prefs) {
        writeFile(PREFS_FILE, gson.toJson(prefs));
    }

    // ── File I/O ──────────────────────────────────────────────────────────────

    private String readFile(String filename) {
        try {
            File f = new File(ctx.getFilesDir(), filename);
            if (!f.exists()) return null;
            BufferedReader reader = new BufferedReader(new FileReader(f));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            reader.close();
            return sb.toString();
        } catch (Exception e) { return null; }
    }

    private void writeFile(String filename, String content) {
        try {
            File f = new File(ctx.getFilesDir(), filename);
            FileWriter writer = new FileWriter(f);
            writer.write(content);
            writer.close();
        } catch (Exception ignored) {}
    }
}
