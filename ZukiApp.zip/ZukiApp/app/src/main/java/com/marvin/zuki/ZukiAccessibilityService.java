package com.marvin.zuki;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads screen content so Zuki can see what's on screen.
 * Required for "What am I looking at?" functionality.
 */
public class ZukiAccessibilityService extends AccessibilityService {

    public static final String ACTION_SCREEN_TEXT = "com.marvin.zuki.SCREEN_TEXT";
    public static final String EXTRA_TEXT = "screen_text";
    public static final String EXTRA_APP = "current_app";

    private static ZukiAccessibilityService instance;

    public static ZukiAccessibilityService getInstance() { return instance; }

    @Override
    public void onServiceConnected() {
        instance = this;
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED |
                          AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 100;
        setServiceInfo(info);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Passive — only reads when asked
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    /**
     * Reads all visible text from the current screen.
     * Called by MainActivity when user asks "what's on my screen?"
     */
    public String readScreen() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return "Nothing visible on screen.";
            StringBuilder sb = new StringBuilder();
            _extractText(root, sb);
            root.recycle();
            String text = sb.toString().trim();
            return text.isEmpty() ? "No readable text on screen." : text;
        } catch (Exception e) {
            return "Could not read screen: " + e.getMessage();
        }
    }

    /**
     * Returns the package name of the currently active app.
     */
    public String getCurrentApp() {
        try {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return "unknown";
            String pkg = root.getPackageName() != null
                    ? root.getPackageName().toString() : "unknown";
            root.recycle();
            return pkg;
        } catch (Exception e) {
            return "unknown";
        }
    }

    private void _extractText(AccessibilityNodeInfo node, StringBuilder sb) {
        if (node == null) return;
        if (node.getText() != null && node.getText().length() > 0) {
            sb.append(node.getText()).append("\n");
        }
        if (node.getContentDescription() != null &&
                node.getContentDescription().length() > 0) {
            sb.append(node.getContentDescription()).append("\n");
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                _extractText(child, sb);
                child.recycle();
            }
        }
    }
}
