package com.marvin.zuki;

import android.content.Intent;
import android.service.voice.VoiceInteractionSession;
import android.service.voice.VoiceInteractionSessionService;

/**
 * Makes Zuki available as the default assistant app.
 * When set as default assistant, holding the home button opens Zuki.
 */
public class ZukiAssistService extends VoiceInteractionSessionService {

    @Override
    public VoiceInteractionSession onNewSession(android.os.Bundle args) {
        return new ZukiSession(this);
    }

    public static class ZukiSession extends VoiceInteractionSession {

        public ZukiSession(android.content.Context context) {
            super(context);
        }

        @Override
        public void onShow(android.os.Bundle args, int showFlags) {
            super.onShow(args, showFlags);
            // Launch MainActivity when home button is held
            Intent intent = new Intent(getContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                           Intent.FLAG_ACTIVITY_SINGLE_TOP |
                           Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("from_assist", true);
            getContext().startActivity(intent);
            hide();
        }
    }
}
