package com.marvin.zuki;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.core.app.NotificationCompat;

/**
 * Floating Zuki bubble that overlays on top of other apps.
 * Tap to open Zuki, long press to dismiss.
 */
public class ZukiOverlayService extends Service {

    private static final String CHANNEL_ID = "zuki_overlay";
    private static final int    NOTIF_ID   = 3001;

    private WindowManager windowManager;
    private View          overlayView;
    private boolean       showing = false;

    @Override
    public void onCreate() {
        super.onCreate();
        _createNotificationChannel();
        startForeground(NOTIF_ID, _buildNotification());
        _createOverlay();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!showing) _showOverlay();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        _removeOverlay();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ── Overlay ───────────────────────────────────────────────────────────────

    private void _createOverlay() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Create bubble button
        Button bubble = new Button(this);
        bubble.setText("Z");
        bubble.setTextColor(0xFFFFFFFF);
        bubble.setTextSize(13);
        bubble.setBackgroundColor(0xFFA129D1);
        bubble.setPadding(0, 0, 0, 0);

        // Make it circular-ish
        bubble.setOnClickListener(v -> {
            // Open Zuki
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            intent.putExtra("from_overlay", true);
            startActivity(intent);
        });

        bubble.setOnLongClickListener(v -> {
            // Dismiss overlay
            stopSelf();
            return true;
        });

        overlayView = bubble;

        // Make draggable
        final WindowManager.LayoutParams[] params = {_makeLayoutParams()};
        final int[] initialX = {0};
        final int[] initialY = {0};
        final float[] initialTouchX = {0};
        final float[] initialTouchY = {0};
        final boolean[] isDragging = {false};

        overlayView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX[0] = params[0].x;
                    initialY[0] = params[0].y;
                    initialTouchX[0] = event.getRawX();
                    initialTouchY[0] = event.getRawY();
                    isDragging[0] = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - initialTouchX[0];
                    float dy = event.getRawY() - initialTouchY[0];
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                        isDragging[0] = true;
                        params[0].x = initialX[0] + (int) dx;
                        params[0].y = initialY[0] + (int) dy;
                        windowManager.updateViewLayout(overlayView, params[0]);
                    }
                    return isDragging[0];
                case MotionEvent.ACTION_UP:
                    return isDragging[0];
            }
            return false;
        });
    }

    private void _showOverlay() {
        if (overlayView.getParent() == null) {
            windowManager.addView(overlayView, _makeLayoutParams());
            showing = true;
        }
    }

    private void _removeOverlay() {
        if (overlayView != null && overlayView.getParent() != null) {
            windowManager.removeView(overlayView);
            showing = false;
        }
    }

    private WindowManager.LayoutParams _makeLayoutParams() {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                90, 90, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 20;
        params.y = 300;
        return params;
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private void _createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Zuki Overlay",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification _buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Zuki")
                .setContentText("Floating overlay active — long press Z to dismiss")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .build();
    }
}
